

        Name: Gary Du Mond
       Stack: Python (Backend) / React(Frontend)
   Wireframe: Attached
Project Name: Trade Journal
      GitHub: https://github.com/Monte42/Trade-Journal



Description:
        Trading Journal where users can get current market values and company data.  Some data
        is charted out.  The user can track their trade history and their thoughts and ideas 
        with that trade(target hold time, target price, etc.).  Users can also monitor their 
        current assets and portfolio diversity. It will have Python/Django/REST API backend 
        with a React Frontend

MVP Features:
            On GitHun
            Has .gitignore
            Full CRUD on user and non-user tables
            CSS (50 shades of gray lol) colored charts
            Validations via Django
            Login / Registration
            Protected Routes

Bonus Features:
            Responsive
            BootStrap
            3rd Party API
            Django

        Planning on doing after class 
                Deploy ( if time )
                Socket.io ( if time )
                Many-to-Many ( if time )