import './App.css';
import {useState,useEffect} from 'react'

function App() {
  const [pokemonList,setPokemonList] = useState([])
  
  useEffect(() => {
    fetch("https://pokeapi.co/api/v2/pokemon?limit=807&offset=0")
      .then(res => res.json())
      .then(response => {
        setPokemonList(response.results)
        console.log(pokemonList)}
        )
  },[])

  return (
    <div className="App">
      <h1>Hello</h1>
      <ul style={{width:"fit-content", margin:"0 auto"}}>
        {pokemonList.map((poke, i) => <li key={i}>{poke.name}</li>)}
      </ul>
    </div>
  );
}

export default App;
