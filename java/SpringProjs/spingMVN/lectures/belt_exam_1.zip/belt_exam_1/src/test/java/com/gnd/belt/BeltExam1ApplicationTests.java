package com.gnd.belt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeltExam1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
