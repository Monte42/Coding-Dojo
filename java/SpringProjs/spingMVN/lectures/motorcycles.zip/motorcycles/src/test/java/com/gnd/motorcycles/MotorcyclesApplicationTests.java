package com.gnd.motorcycles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MotorcyclesApplicationTests {

	@Test
	void contextLoads() {
	}

}
