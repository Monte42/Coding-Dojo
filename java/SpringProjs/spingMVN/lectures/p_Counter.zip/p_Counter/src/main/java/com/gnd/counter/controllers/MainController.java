package com.gnd.counter.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
	@RequestMapping("/")
	public String homePage(HttpSession session) {
		if (session.getAttribute("count")==null) {
			session.setAttribute("count", 0);
		}
		int count = (int) session.getAttribute("count");
		session.setAttribute("count", count+1);
		return "index.jsp";
	}
	
	@RequestMapping("/double")
	public String doublePage(HttpSession session) {
		if (session.getAttribute("count")==null) {
			session.setAttribute("count", 0);
		}
		int count = (int) session.getAttribute("count");
		session.setAttribute("count", count+2);
		return "double.jsp";
	}
	
	@RequestMapping("/counter")
	public String aboutPage(HttpSession session, Model model) {
		model.addAttribute("count", session.getAttribute("count"));
		return "about.jsp";
	}
	
	@RequestMapping("/reset")
	public String reset(HttpSession session) {
		session.removeAttribute("count");
		return "redirect:/counter";
	}
}
