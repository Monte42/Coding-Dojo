package com.gnd.omikuji;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class COmikujiApplication {

	public static void main(String[] args) {
		SpringApplication.run(COmikujiApplication.class, args);
	}

}
