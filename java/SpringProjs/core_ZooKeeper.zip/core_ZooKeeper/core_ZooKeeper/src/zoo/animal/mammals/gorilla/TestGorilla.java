package zoo.animal.mammals.gorilla;

public class TestGorilla {
	
	public static void main (String[] args) {

		Gorilla gorillaJames = new Gorilla(2,true,"James");
		gorillaJames.displayEnergy();
		gorillaJames.throwSomething();
		gorillaJames.throwSomething();
		gorillaJames.throwSomething();
		gorillaJames.eatBananas();
		gorillaJames.eatBananas();
		gorillaJames.climb();
		gorillaJames.displayEnergy();

	}

}
