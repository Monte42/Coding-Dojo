package zoo.animal.mammals.bat;

public class TestBat {

	public static void main(String[] args) {

		Bat batty = new Bat();
		batty.displayEnergy();
		batty.attackTown();
		batty.eatHumans();
		batty.eatHumans();
		batty.eatHumans();
		batty.fly();
		batty.attackTown();
		batty.eatHumans();
		batty.eatHumans();
		batty.fly();
		batty.attackTown();
		batty.eatHumans();
		batty.displayEnergy();
		

	}

}
